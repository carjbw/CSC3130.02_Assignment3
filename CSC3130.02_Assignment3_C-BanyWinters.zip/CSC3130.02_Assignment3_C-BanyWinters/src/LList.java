public interface LList {
    public void listAdd(Book p);
    public void listRemove(int pos);
    public void grow();
    public void updatePointers(int pos, int addRemove);
    public void updateHead(SLNode Node);
}
