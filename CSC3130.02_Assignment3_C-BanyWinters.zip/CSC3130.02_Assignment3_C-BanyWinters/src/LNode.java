public interface LNode {
    public void setNext(SLNode next);
    public SLNode getNext();
    public Book getData();
}
