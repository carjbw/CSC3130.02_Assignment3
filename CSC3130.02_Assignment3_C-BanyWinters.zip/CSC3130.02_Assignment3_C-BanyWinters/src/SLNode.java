public class SLNode implements LNode{
    Book data;
    SLNode next;
    public SLNode(Book data) {
        this.data = data;
        next = null;
    }
    @Override
    public void setNext(SLNode next) {this.next = next;}
    @Override
    public SLNode getNext() {return next;}
    @Override
    public Book getData() {return data;}
}
