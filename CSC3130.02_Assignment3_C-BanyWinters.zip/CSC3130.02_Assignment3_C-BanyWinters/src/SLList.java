public class SLList implements LList {
    SLNode[] list;
    int size; int maxSize;
    SLNode head;

    public SLList() {
        maxSize = 100;
        list = new SLNode[maxSize];
        size = 0;
        head = null;
    }

    @Override
    public void listAdd(Book p) {
        // Grow list if size has reached limit
        if(size >= maxSize) {
            grow();
        }
        // Create a new node and pass the element as a param
        SLNode node = new SLNode(p);
        int insertPos = size; // Pos in list where new element will be added
        // Insert the element
        list[insertPos] = node;
        // Update pointers (param addRemove = 1 for add)
        updatePointers(insertPos, 1);
        // Update head (if head == null)
        updateHead(node);
        // 1 element was added to list -> increment size by 1
        size++;
    }

    @Override
    public void listRemove(int pos) {
        list[pos] = null;
        updatePointers(pos, -1);
    }

    public String toString() {
        String listString = head.getData().getInfo();
        for(int i = 0; (i < size) && (list[i].getNext() != null); i++) {
            listString += "\n" + list[i].getNext().getData().getInfo();
        }
        return listString;
    }

    public void grow() {
        int newMax = maxSize+1;
        SLNode[] newList = new SLNode[newMax];
        for(int i = 0; i < size; i++) {
            newList[i] = list[i];
        }
        list = newList;
        maxSize = newMax;
    }

    public void updatePointers(int pos, int addRemove) {
        /*
        addRemove > 0 -> add
        addRemove < 0 -> remove
         */
        // Verify that added element is NOT first in list
        if((addRemove > 0) && (pos > 0)) {
            // Update next value pof previous node (next = this node)
            list[pos-1].setNext(list[pos]);
        }
        // Verify that removed element is NOT last in list
        else if((addRemove < 0) && ((pos+1) < size)) {
            // Update next value of previous node (next = node directly after this node)
            list[pos-1].setNext(list[pos+1]);
        }
    }

    public void updateHead(SLNode node) {
        if(head == null) {
            head = node;
        }
    }
}
