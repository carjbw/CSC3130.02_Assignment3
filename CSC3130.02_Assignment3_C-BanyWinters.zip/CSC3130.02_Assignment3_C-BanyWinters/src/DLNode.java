public class DLNode {
    Book data;
    DLNode next = null;
    DLNode prev = null;
    int pos;
    public DLNode(Book data, int pos) {
        this.data = data;
        this.pos = pos;
    }
    public void setNext(DLNode next) {
        this.next = next;
    }
    public void setPrev(DLNode prev) {
        this.prev = prev;
    }
}
