public class AList {
    int maxSize = 100;
    Book[] list = new Book[maxSize];
    int size = 0;
    public AList() {
    }
    /*
    Add an element (type: Book) to list
    @param Book p : the element being added
     */
    public void listAdd(Book p) {
        // Check if size has reached (or exceeded) maxSize
        if(size >= maxSize) {
            // MaxSize reached -> replace list with new list that has size+1
            list = grow();
        }
        // Insert element at next available position
        list[size] = p;
        // 1 new element added -> increment size by 1
        size++;
    }
    /*
    Remove an element at a given position within list from list.
    @param int pos : the position of the element being removed
     */
    public void listRemove(int pos) {
        // Iterate thru list starting at the pos of the element being removed
        for(int i = pos; i < (size-1); i++) {
            // Replace this element with the next element
            list[pos] = list[pos+1];
            // Continue this process, shifting all elements one to the left
        }
        // 1 element removed -> decrement size by 1
        size = size-1;
    }
    /*
    Get the contents of list in the form of a String, with each element in its
        own line.
    @return String : the elements in list
     */
    public String toString() {
        String AString = "";
        for(int i = 0; i < size && (list[i] != null); i++) {
            AString += list[i].getInfo() + "\n";
        }
        return AString;
    }
    /*
    Helper method: get list (type: Book) that shares all elements with list, but has
        the capacity for one additional element.
    @return Book[] : a new list of Book elements
     */
    private Book[] grow() {
        Book[] newList = new Book[maxSize+1];
        for(int i = 0; i < list.length; i++) {
            newList[i] = list[i];
        }
        maxSize++;
        return newList;
    }
}
