public class DLList implements LList{
    DLNode head = null;
    int maxSize = 100;
    DLNode[] list = new DLNode[maxSize];
    int size = 0;
    int pos = 0;
    public DLList() {
    }
    @Override
    public void listAdd(Book p) {
        if(size >= maxSize) {
            grow();
        }
        DLNode node = new DLNode(p, pos);
        if(pos > 0) {
            node.setPrev(list[pos-1]);
            list[pos-1].setNext(node);
        }
        list[pos] = node;
        if(head == null) {
            head = node;
        }
        pos++; size++;
    }
    @Override
    public void listRemove(int pos) {
        list[pos] = null;
        int endPos = size-1;
        if(pos < endPos) {
            list[pos-1].setNext(list[pos+1]);
            list[pos+1].setPrev(list[pos-1]);
        }
    }
    public String toString() {
        String listString = "";
        return listString;
    }
    public void grow() {
        int newMax = maxSize + 1;
        DLNode[] newList = new DLNode[newMax];
        for (int i = 0; i < size; i++) {
            newList[i] = list[i];
        }
        list = newList;
        maxSize = newMax;
    }

    @Override
    public void updatePointers(int pos, int addRemove) {

    }

    @Override
    public void updateHead(SLNode Node) {

    }
}
